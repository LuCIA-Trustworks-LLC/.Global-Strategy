# AegisAI Component Registry
2026-11-25 JST。作業環境の観測と正本への帰属を分離する。

| 資産 | 出所と確認証拠 | 正本への帰属 |
|---|---|---|
| 既存ホームページ | `/workspace/scratch/fa6281763949/reference-homepage` の React/Vinext ソース。既存配布物 `AegisAI-reference-homepage.tar.gz` 内の `app/page.tsx` と、展開済みファイルの SHA-256 が一致 | 参照資産。Kernel との接続や正本内の配置は未確認 |
| 独立承認デモ | `/workspace/scratch/e00ceb1d0270/aegisai_approval_demo.py`。独立 Python プロセスの承認・実行例。コミットや作成者の帰属は未確認 | 正本への由来・接続を示す証拠なし |
| Kernel 設計資料 | [PROJECT-MANIFEST.md](https://chatgpt.com/library?file_id=libfile_9f2ef17ee1f48191ae1643659cd3406d&account_id=personal) を前回読了。ドラフトに Kernel、Runtime、Policy と Grant の設計が記載 | 設計資料。実装ソースと承認済み版は未確認 |
| GitHub ガバナンス | `LuCIA-Trustworks-LLC/.Global-Strategy`。直接照会で public、既定ブランチ main | カーネル実装の正本とする証拠なし |
| Kernel、Runtime、Policy Engine、Authorization Grant、EvidenceRecord、正本テスト | 期待値 `~/aegisai_project`。本作業環境上のパス不在。正本 URL／ref 未確定 | BLOCKED。正本にどの実装が存在するかは未確認 |
| 旧 Python/RAG | 期待値 `~/AegisAI`。本環境のパス不在 | NOT VERIFIED |
| 統合チャット、Dashboard、管理 | 本作業環境で正本との統合証拠を確認できていない | BLOCKED |

ホームページは広報と技術説明を担い、デモは承認手順を独立して例示し、マニフェストは認可・実行境界の設計を記述する。三者に共通するのはプロジェクト名と設計主題。相互の呼び出し関係と正本ソースへの系譜は未確認。

| 対象 | SHA-256 |
|---|---|
| ホームページアーカイブ | `caba1bfe2bf12cf1a7b6a35aa039caf154de763650babaa6b2886c5dc1830ac6` |
| アーカイブ内と展開済みの app/page.tsx | `d08b37d50557a7c568233bcd093bf4589855d0b055934e3b9dbf269212f27db6` |
| 独立承認デモ | `5232cfb51909f00ad9dd3b8968f104d6fc8feef34c4f1554db758e4e03482653` |
