/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
The app main entry point.
*/

import SwiftUI

@main
struct TextKitAndTextViewSampleAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
