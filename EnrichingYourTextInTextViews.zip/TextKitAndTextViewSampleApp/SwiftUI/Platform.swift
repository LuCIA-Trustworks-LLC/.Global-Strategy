/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
Types and extensions for platform-dependent abstractions.
*/

#if os(macOS)
@_exported import AppKit
typealias PlatformView = NSView
typealias PlatformTextView = NSTextView
typealias PlatformTextViewDelegate = NSTextViewDelegate
typealias PlatformImage = NSImage
typealias PlatformImageView = NSImageView
typealias PlatformColor = NSColor
typealias PlatformFont = NSFont
typealias PlatformBezierPath = NSBezierPath
#else
@_exported import UIKit
typealias PlatformView = UIView
typealias PlatformTextView = UITextView
typealias PlatformTextViewDelegate = UITextViewDelegate
typealias PlatformImage = UIImage
typealias PlatformImageView = UIImageView
typealias PlatformColor = UIColor
typealias PlatformFont = UIFont
typealias PlatformBezierPath = UIBezierPath
#endif

// MARK: - Color Helpers

extension PlatformColor {
    static var platformTextColor: PlatformColor {
        #if os(macOS)
        .textColor
        #else
        .label
        #endif
    }

    static var platformSecondaryLabel: PlatformColor {
        #if os(macOS)
        .secondaryLabelColor
        #else
        .secondaryLabel
        #endif
    }
}

// MARK: - Bezier Path Helpers

#if os(macOS)
extension NSBezierPath {
    // Convenience initializer matching UIBezierPath's `init(roundedRect:cornerRadius:)`.
    convenience init(roundedRect rect: CGRect, cornerRadius: CGFloat) {
        self.init(roundedRect: rect, xRadius: cornerRadius, yRadius: cornerRadius)
    }
}
#endif

// MARK: - Font Helpers

extension PlatformFont {
    static func platformPreferredFont(forTextStyle style: TextStyle) -> PlatformFont {
        #if os(macOS)
        .preferredFont(forTextStyle: style, options: [:])
        #else
        .preferredFont(forTextStyle: style)
        #endif
    }
}

// MARK: - Font Trait Helpers

#if os(macOS)
extension NSFontDescriptor.SymbolicTraits {
    static var platformItalic: NSFontDescriptor.SymbolicTraits { .italic }
    static var platformBold: NSFontDescriptor.SymbolicTraits { .bold }
}
#else
extension UIFontDescriptor.SymbolicTraits {
    static var platformItalic: UIFontDescriptor.SymbolicTraits { .traitItalic }
    static var platformBold: UIFontDescriptor.SymbolicTraits { .traitBold }
}
#endif

// MARK: - Container View Helpers
class PlatformContainerView: PlatformView {
#if os(macOS)
    let scrollView = NSScrollView()
#endif

#if os(macOS)
    private func setupTextView(_ textView: PlatformTextView) {
        textView.isVerticallyResizable = true
        textView.autoresizingMask = .width
        textView.textContainer?.widthTracksTextView = true
        textView.maxSize = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
    }
#endif
    func setupConstraints(_ contentView: PlatformView ) {
        NSLayoutConstraint.activate([
            contentView.leadingAnchor.constraint(equalTo: leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: trailingAnchor),
            contentView.topAnchor.constraint(equalTo: topAnchor),
            contentView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    func setupLayout(_ textView: PlatformTextView) {
#if os(macOS)
        setupTextView(textView)
        
        let contentView = scrollView
        scrollView.documentView = textView
        scrollView.hasVerticalScroller = true
        scrollView.autohidesScrollers = true
#else
        let contentView = textView
#endif
        contentView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(contentView)
        setupConstraints(contentView)
    }
}
