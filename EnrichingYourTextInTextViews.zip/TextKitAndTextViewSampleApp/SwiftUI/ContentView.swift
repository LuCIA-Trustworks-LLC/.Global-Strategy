/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
The main view that hosts the sidebar to switch views for different examples.
*/

import SwiftUI

enum SidebarItem: Hashable {
    case lineNumbering
    case sectionCollapsing
    case inlineAttachments
    case exclusionPath
    case textAttachment
    case textList
}

struct ContentView: View {
    @State private var selection: SidebarItem?

    var body: some View {
        NavigationSplitView {
            List(selection: $selection) {
                Section("Text Views") {
                    Label("Line Numbering", systemImage: "list.number")
                        .tag(SidebarItem.lineNumbering)
                    Label("Section Collapsing", systemImage: "rectangle.compress.vertical")
                        .tag(SidebarItem.sectionCollapsing)
                    Label("Inline Attachments", systemImage: "paperclip")
                        .tag(SidebarItem.inlineAttachments)
                    Label("Exclusion Path", systemImage: "text.word.spacing")
                        .tag(SidebarItem.exclusionPath)
                    Label("Attachment", systemImage: "doc.richtext")
                        .tag(SidebarItem.textAttachment)
                    Label("List", systemImage: "list.bullet")
                        .tag(SidebarItem.textList)
                }
            }
            .navigationTitle("TextKit")
        } detail: {
            Group {
                switch selection {
                case .lineNumbering:
                    LineNumberingView()
                case .sectionCollapsing:
                    SectionCollapsingView()
                case .inlineAttachments:
                    InlineAttachmentsView()
                case .exclusionPath:
                    ExclusionPathView()
                case .textAttachment:
                    TextAttachmentView()
                case .textList:
                    TextListView()
                case nil:
                    Text("Select an item from the sidebar")
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
