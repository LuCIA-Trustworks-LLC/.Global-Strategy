/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
SwiftUI views and representable wrappers for each example.
*/

import SwiftUI

// MARK: - Line Numbering

struct LineNumberingView: View {
    var body: some View {
        LineNumberingRepresentable()
    }
}

#if os(macOS)
private struct LineNumberingRepresentable: NSViewRepresentable {
    func makeNSView(context: Context) -> LineNumberingContainerView { LineNumberingContainerView() }
    func updateNSView(_ nsView: LineNumberingContainerView, context: Context) {}
}
#else
private struct LineNumberingRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> LineNumberingContainerView { LineNumberingContainerView() }
    func updateUIView(_ uiView: LineNumberingContainerView, context: Context) {}
}
#endif

// MARK: - Section Collapsing

struct SectionCollapsingView: View {
    var body: some View {
        SectionCollapsingRepresentable()
    }
}

#if os(macOS)
private struct SectionCollapsingRepresentable: NSViewRepresentable {
    func makeNSView(context: Context) -> SectionCollapsingContainerView { SectionCollapsingContainerView() }
    func updateNSView(_ nsView: SectionCollapsingContainerView, context: Context) {}
}
#else
private struct SectionCollapsingRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> SectionCollapsingContainerView { SectionCollapsingContainerView() }
    func updateUIView(_ uiView: SectionCollapsingContainerView, context: Context) {}
}
#endif

// MARK: - Exclusion Path

struct ExclusionPathView: View {
    var body: some View {
        ExclusionPathRepresentable()
    }
}

#if os(macOS)
private struct ExclusionPathRepresentable: NSViewRepresentable {
    func makeNSView(context: Context) -> ExclusionPathContainerView { ExclusionPathContainerView() }
    func updateNSView(_ nsView: ExclusionPathContainerView, context: Context) {}
}
#else
private struct ExclusionPathRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> ExclusionPathContainerView { ExclusionPathContainerView() }
    func updateUIView(_ uiView: ExclusionPathContainerView, context: Context) {}
}
#endif

// MARK: - Text Attachment

struct TextAttachmentView: View {
    var body: some View {
        TextAttachmentRepresentable()
    }
}

#if os(macOS)
private struct TextAttachmentRepresentable: NSViewRepresentable {
    func makeNSView(context: Context) -> TextAttachmentContainerView { TextAttachmentContainerView() }
    func updateNSView(_ nsView: TextAttachmentContainerView, context: Context) {}
}
#else
private struct TextAttachmentRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> TextAttachmentContainerView { TextAttachmentContainerView() }
    func updateUIView(_ uiView: TextAttachmentContainerView, context: Context) {}
}
#endif

// MARK: - Text List

struct TextListView: View {
    var body: some View {
        TextListRepresentable()
    }
}

#if os(macOS)
private struct TextListRepresentable: NSViewRepresentable {
    func makeNSView(context: Context) -> ListContainerView { ListContainerView() }
    func updateNSView(_ nsView: ListContainerView, context: Context) {}
}
#else
private struct TextListRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> ListContainerView { ListContainerView() }
    func updateUIView(_ uiView: ListContainerView, context: Context) {}
}
#endif

// MARK: - Inline Attachments

struct InlineAttachmentsView: View {
    var body: some View {
        InlineAttachmentsRepresentable()
    }
}

#if os(macOS)
private struct InlineAttachmentsRepresentable: NSViewRepresentable {
    func makeNSView(context: Context) -> InlineAttachmentsContainerView { InlineAttachmentsContainerView() }
    func updateNSView(_ nsView: InlineAttachmentsContainerView, context: Context) {}
}
#else
private struct InlineAttachmentsRepresentable: UIViewRepresentable {
    func makeUIView(context: Context) -> InlineAttachmentsContainerView { InlineAttachmentsContainerView() }
    func updateUIView(_ uiView: InlineAttachmentsContainerView, context: Context) {}
}
#endif
