/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
Logic for text list view.
*/

// MARK: - Container View

class ListContainerView: PlatformView {
    #if os(macOS)
    let textView = PlatformTextView(frame: .zero)
    let scrollView = NSScrollView()
    let styleControl = NSPopUpButton()
    #else
    let textView = PlatformTextView()
    let styleControl = UISegmentedControl(items: ["Decimal", "Disc", "Square"])
    #endif

    override init(frame: CGRect) {
        super.init(frame: frame)

        #if os(macOS)
        textView.isVerticallyResizable = true
        textView.autoresizingMask = .width
        textView.textContainer?.widthTracksTextView = true
        textView.maxSize = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
        textView.textStorage?.loadListSampleText()

        scrollView.documentView = textView
        scrollView.hasVerticalScroller = true
        scrollView.autohidesScrollers = true

        styleControl.addItems(withTitles: ["Decimal", "Disc", "Square"])
        styleControl.target = self
        styleControl.action = #selector(setListMarkerStyle)
        #else
        textView.textStorage.loadListSampleText()

        styleControl.selectedSegmentIndex = 0
        styleControl.addTarget(self, action: #selector(setListMarkerStyle), for: .valueChanged)
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        #endif

        setupLayout()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func setupLayout() {
        #if os(macOS)
        let contentView = scrollView
        #else
        let contentView = textView
        #endif
        styleControl.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(styleControl)
        addSubview(contentView)

        #if os(macOS)
        let topConstraint = styleControl.topAnchor.constraint(equalTo: topAnchor, constant: 8)
        #else
        let topConstraint = styleControl.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 8)
        #endif

        NSLayoutConstraint.activate([
            topConstraint,
            styleControl.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8),
            contentView.topAnchor.constraint(equalTo: styleControl.bottomAnchor, constant: 8),
            contentView.leadingAnchor.constraint(equalTo: leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    @objc
    private func setListMarkerStyle() {
        #if os(macOS)
        guard let textLayoutManager = textView.textLayoutManager,
              let textStorage = textView.textStorage else { return }
        let styleIndex = styleControl.indexOfSelectedItem
        #else
        guard let textLayoutManager = textView.textLayoutManager else { return }
        let textStorage = textView.textStorage
        let styleIndex = styleControl.selectedSegmentIndex
        #endif
        textLayoutManager.textContentManager?.performEditingTransaction {
            textStorage.setListMarkerStyle(styleIndex: styleIndex)
        }
    }
}

// MARK: - Sample Text Loading

private extension NSTextStorage {
    // Load a plain text list and apply decimal list marker formatting.
    func loadListSampleText() {
        guard let fileURL = Bundle.main.url(forResource: "ListSample", withExtension: "txt") else {
            fatalError("Failed to find ListSample.txt in the app bundle.")
        }
        guard let sampleText = try? String(contentsOf: fileURL, encoding: .utf8) else {
            fatalError("Failed to load sample text.")
        }
        let sampleContents = NSAttributedString(string: sampleText)
        replaceCharacters(in: NSRange(location: 0, length: length), with: sampleContents)

        guard let paragraphStyle = NSParagraphStyle.default.mutableCopy() as? NSMutableParagraphStyle else { return }
        let textList = NSTextList(markerFormat: .decimal, options: 0)
        paragraphStyle.textLists = [textList]

        let textColor = PlatformColor.platformTextColor

        let attributes: [NSAttributedString.Key: Any] = [
            .paragraphStyle: paragraphStyle,
            .foregroundColor: textColor
        ]
        let listAttributedString = NSAttributedString(string: string, attributes: attributes)
        replaceCharacters(in: NSRange(location: 0, length: length), with: listAttributedString)
    }

    // Change the list marker style for all text lists in the storage.
    func setListMarkerStyle(styleIndex: Int) {
        guard styleIndex >= 0 && styleIndex < 3 else { return }
        let markerFormats: [NSTextList.MarkerFormat] = [.decimal, .disc, .square]
        let newMarkerFormat = markerFormats[styleIndex]

        var pos = 0
        while pos < length {
            var pstyleRange = NSRange(location: NSNotFound, length: 0)
            let searchRange = NSRange(location: pos, length: length - pos)
            let value = attribute(.paragraphStyle, at: pos, longestEffectiveRange: &pstyleRange, in: searchRange)
            if let pstyle = value as? NSParagraphStyle {
                if !pstyle.textLists.isEmpty, let mutablePstyle = pstyle.mutableCopy() as? NSMutableParagraphStyle {
                    mutablePstyle.textLists = mutablePstyle.textLists.map { _ in
                        NSTextList(markerFormat: newMarkerFormat, options: 0)
                    }
                    addAttribute(.paragraphStyle, value: mutablePstyle, range: pstyleRange)
                }
            }
            pos = NSMaxRange(pstyleRange)
        }
    }
}
