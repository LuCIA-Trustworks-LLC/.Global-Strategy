/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
Logic for section collapsing text view.
*/

// MARK: - Container View

// Places the disclosure gutter to the left of the text view.
class SectionCollapsingContainerView: PlatformContainerView {
    fileprivate let gutterView = DisclosureGutterView()
    fileprivate let textView = CollapsibleTextView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        textView.gutterView = gutterView
        // Make the text view read-only to avoid incremental updates to the paragraph cache because that isn't the focus of this sample app.
        // Real-world apps can support editing by updating the cache when the text changes.
        textView.isEditable = false
        gutterView.onToggle = { [weak self] headerOffset in
            self?.textView.toggleSection(headerOffset: headerOffset)
        }
        setupLayout(textView)
        loadSampleText()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func loadSampleText() {
        guard let fileURL = Bundle.main.url(forResource: "menu", withExtension: "rtf") else {
            fatalError("Failed to find menu.rtf in the app bundle.")
        }
        guard let textContentStorage = textView.textLayoutManager?.textContentManager as? NSTextContentStorage,
              let textStorage = textContentStorage.textStorage,
              let attributedString = try? NSAttributedString(url: fileURL, options: [:], documentAttributes: nil) else { return }
        textContentStorage.performEditingTransaction {
            textStorage.setAttributedString(attributedString)
        }

        textView.textColor = PlatformColor.platformTextColor
        textView.setupContentStorageDelegate()
    }

    override func setupConstraints(_ contentView: PlatformView ) {
        NSLayoutConstraint.activate([
            gutterView.leadingAnchor.constraint(equalTo: leadingAnchor),
            gutterView.topAnchor.constraint(equalTo: topAnchor),
            gutterView.bottomAnchor.constraint(equalTo: bottomAnchor),
            gutterView.widthAnchor.constraint(equalToConstant: 30),
            contentView.leadingAnchor.constraint(equalTo: gutterView.trailingAnchor),
            contentView.trailingAnchor.constraint(equalTo: trailingAnchor),
            contentView.topAnchor.constraint(equalTo: topAnchor),
            contentView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    override func setupLayout(_ textView: PlatformTextView) {
        gutterView.translatesAutoresizingMaskIntoConstraints = false

        addSubview(gutterView)
        super.setupLayout(textView)
    }
}

// MARK: - Collapsible Text View

// A text view subclass that hides body paragraphs under collapsed headers using the
// NSTextContentStorageDelegate filtering mechanism.
// Updates the disclosure gutter via the NSTextViewportLayoutControllerDelegate methods
// that UITextView/NSTextView already implements as the delegate.
private class CollapsibleTextView: PlatformTextView, NSTextContentStorageDelegate {
    weak var gutterView: DisclosureGutterView?

    // Document offsets of collapsed header paragraphs.
    var collapsedSections: Set<Int> = []

    // Gutter entries accumulated during the current layout pass.
    private var collectedEntries: [DisclosureGutterView.Entry] = []

    func setupContentStorageDelegate() {
        guard let contentStorage = textLayoutManager?.textContentManager as? NSTextContentStorage else { return }
        contentStorage.delegate = self
    }

    func toggleSection(headerOffset: Int) {
        if collapsedSections.contains(headerOffset) {
            collapsedSections.remove(headerOffset)
        } else {
            collapsedSections.insert(headerOffset)
        }
        guard let textLayoutManager = textLayoutManager else { return }

        let textViewportLayoutController = textLayoutManager.textViewportLayoutController
        textViewportLayoutController.delegate?.textViewportLayoutControllerReceivedSetNeedsLayout?(textViewportLayoutController)
    }

    // MARK: NSTextViewportLayoutControllerDelegate

    override func textViewportLayoutControllerWillLayout(_ textViewportLayoutController: NSTextViewportLayoutController) {
        super.textViewportLayoutControllerWillLayout(textViewportLayoutController)
        collectedEntries.removeAll()
    }

    override func textViewportLayoutController (
        _ textViewportLayoutController: NSTextViewportLayoutController,
        configureRenderingSurfaceFor textLayoutFragment: NSTextLayoutFragment) {
        super.textViewportLayoutController(textViewportLayoutController, configureRenderingSurfaceFor: textLayoutFragment)

        // If this fragment is a header paragraph, record it for the gutter.
        if let paragraph = textLayoutFragment.textElement as? NSTextParagraph,
           Self.isHeaderParagraph(paragraph) {
            let offset = documentOffset(for: paragraph)
            let collapsed = collapsedSections.contains(offset)
            collectedEntries.append(DisclosureGutterView.Entry(
                headerOffset: offset,
                frame: textLayoutFragment.layoutFragmentFrame,
                isCollapsed: collapsed
            ))
        }
    }

    override func textViewportLayoutControllerDidLayout (_ textViewportLayoutController: NSTextViewportLayoutController) {
        super.textViewportLayoutControllerDidLayout(textViewportLayoutController)

        guard let gutterView else { return }

        // Adjust collected positions from text container coordinates to viewport coordinates.
        let viewportOriginY = textViewportLayoutController.viewportBounds.minY
        let adjustedEntries = collectedEntries.map { entry in
            let yOrigin = entry.frame.minY - viewportOriginY
            let frame = CGRect(x: 0, y: yOrigin, width: gutterView.bounds.width, height: entry.frame.height)
            return DisclosureGutterView.Entry(headerOffset: entry.headerOffset, frame: frame, isCollapsed: entry.isCollapsed)
        }
        gutterView.rebuild(with: adjustedEntries)
    }

    // MARK: NSTextContentStorageDelegate

    func textContentManager(_ textContentManager: NSTextContentManager,
                            shouldEnumerate textElement: NSTextElement,
                            options: NSTextContentManager.EnumerationOptions) -> Bool {
        guard let paragraph = textElement as? NSTextParagraph else { return true }
        // Headers are always visible.
        if Self.isHeaderParagraph(paragraph) { return true }
        // For body paragraphs, walk backwards to find the owning header.
        guard let contentStorage = textContentManager as? NSTextContentStorage,
              let owningHeaderOffset = findOwningHeaderOffset(for: paragraph, in: contentStorage) else { return true }
        return !collapsedSections.contains(owningHeaderOffset)
    }

    // MARK: Helpers

    // Walk backwards from the given paragraph to find the nearest header.
    // Returns the document offset of that header, or nil if no header precedes it.
    private func findOwningHeaderOffset(for paragraph: NSTextParagraph,
                                        in contentStorage: NSTextContentStorage) -> Int? {
        guard let elementRange = paragraph.elementRange else { return nil }
        var result: Int? = nil
        contentStorage.enumerateTextElements(from: elementRange.location, options: .reverse) { element in
            guard let prev = element as? NSTextParagraph else { return true }
            if Self.isHeaderParagraph(prev) {
                result = self.documentOffset(for: prev)
                return false
            }
            return true
        }
        return result
    }

    // Compute the document offset for a paragraph (used as its stable identity).
    private func documentOffset(for paragraph: NSTextParagraph) -> Int {
        guard let contentStorage = textLayoutManager?.textContentManager as? NSTextContentStorage,
              let elementRange = paragraph.elementRange else { return 0 }
        return contentStorage.offset(from: contentStorage.documentRange.location, to: elementRange.location)
    }

    // Detect headers by checking for the italic font trait on the first character.
    // The sample document (menu.rtf) uses italic formatting for section headers.
    private static func isHeaderParagraph(_ paragraph: NSTextParagraph) -> Bool {
        let attrString = paragraph.attributedString
        guard attrString.length > 0 else { return false }
        guard let font = attrString.attribute(.font, at: 0, effectiveRange: nil) as? PlatformFont else { return false }
        return font.fontDescriptor.symbolicTraits.contains(.platformItalic)
    }
}

// MARK: - Disclosure Gutter View

// Draws disclosure triangles next to header paragraphs and handles click-to-toggle.
private class DisclosureGutterView: PlatformView {
    struct Entry {
        let headerOffset: Int
        let frame: CGRect
        let isCollapsed: Bool
    }

    var onToggle: ((Int) -> Void)?
    private var entries: [Entry] = []

    #if os(macOS)
    override var isFlipped: Bool { true }
    #else
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .systemBackground
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        addGestureRecognizer(tap)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    #endif

    func rebuild(with entries: [Entry]) {
        self.entries = entries
        #if os(macOS)
        needsDisplay = true
        #else
        setNeedsDisplay()
        #endif
    }

    override func draw(_ rect: CGRect) {
        let attributes: [NSAttributedString.Key: Any] = [
            .font: PlatformFont.systemFont(ofSize: 12, weight: .regular),
            .foregroundColor: PlatformColor.platformSecondaryLabel
        ]
        for entry in entries {
            guard entry.frame.intersects(rect) else { continue }
            let symbol: String = entry.isCollapsed ? "\u{25B6}" : "\u{25BC}"
            let label = symbol as NSString
            let labelSize = label.size(withAttributes: attributes)
            let xOrigin = (bounds.width - labelSize.width) / 2
            let yOrigin = entry.frame.minY + (entry.frame.height - labelSize.height) / 2
            label.draw(at: CGPoint(x: xOrigin, y: yOrigin), withAttributes: attributes)
        }
    }

    #if os(macOS)
    override func mouseDown(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        for entry in entries where entry.frame.contains(point) {
            onToggle?(entry.headerOffset)
            return
        }
        super.mouseDown(with: event)
    }
    #else
    @objc
    private func handleTap(_ gesture: UITapGestureRecognizer) {
        let point = gesture.location(in: self)
        for entry in entries where entry.frame.contains(point) {
            onToggle?(entry.headerOffset)
            return
        }
    }
    #endif
}
