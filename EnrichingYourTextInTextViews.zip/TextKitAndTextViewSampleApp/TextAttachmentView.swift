/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
Logic for text attachment container view.
*/

// MARK: - Container View

class TextAttachmentContainerView: PlatformContainerView {
    let textView = PlatformTextView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout(textView)
        #if !os(macOS)
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        #endif

        guard let textLayoutManager = textView.textLayoutManager,
              let textContentStorage = textLayoutManager.textContentManager as? NSTextContentStorage,
              let textStorage = textContentStorage.textStorage else { return }
        textStorage.loadAttachmentSampleText(textLayoutManager: textLayoutManager)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

// MARK: - View-Based Text Attachment

// An interactive "Show more" / "Show less" button rendered as a view-based text attachment.
private class AttachmentButtonView: PlatformView {
    var textAttachment: ExpandableAttachment?
    private var isPressed = false

    override var intrinsicContentSize: CGSize {
        var result = CGSize(width: 60, height: labelText.size().height)
        result.width += xPadding * 2
        result.height += yPadding * 2
        return result
    }

    #if os(macOS)
    var xPadding: CGFloat { 3 }
    var yPadding: CGFloat { 1 }
    var cornerRadius: CGFloat { 3 }
    #else
    var xPadding: CGFloat { 5 }
    var yPadding: CGFloat { 5 }
    var cornerRadius: CGFloat { 10 }
    #endif

    var fillColor: PlatformColor {
        #if os(macOS)
        isPressed ? .selectedControlColor : .systemBlue
        #else
        isPressed ? .systemGray : .systemBlue
        #endif
    }

    var labelText: NSAttributedString {
        let string = (textAttachment?.hiddenContent != nil) ? "Show more" : "Show less"
        var labelFont = PlatformFont.platformPreferredFont(forTextStyle: .caption2)
        let boldDescriptor = labelFont.fontDescriptor.withSymbolicTraits(.platformBold)
        #if os(macOS)
        labelFont = PlatformFont(descriptor: boldDescriptor, size: labelFont.pointSize)!
        #else
        labelFont = PlatformFont(descriptor: boldDescriptor!, size: labelFont.pointSize)
        #endif
        let attributes: [NSAttributedString.Key: Any] = [
            .font: labelFont,
            .foregroundColor: PlatformColor.white
        ]
        return NSAttributedString(string: string, attributes: attributes)
    }

    // MARK: Event Handling

    #if os(macOS)
    override func mouseDown(with event: NSEvent) {
        isPressed = true
        needsDisplay = true
    }

    override func mouseUp(with event: NSEvent) {
        isPressed = false
        textAttachment?.toggleHidden()
        invalidateIntrinsicContentSize()
        needsDisplay = true
    }
    #else
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        isPressed = true
        setNeedsDisplay()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        isPressed = false
        textAttachment?.toggleHidden()
        invalidateIntrinsicContentSize()
        setNeedsDisplay()
    }
    #endif

    // MARK: Drawing

    override func draw(_ rect: CGRect) {
        #if os(macOS)
        NSColor.clear.set()
        bounds.fill()
        #else
        UIColor.systemBackground.set()
        UIRectFill(bounds)
        #endif
        fillColor.set()
        PlatformBezierPath(roundedRect: bounds, cornerRadius: cornerRadius).fill()
        let labelSize = labelText.size()
        labelText.draw(at: CGPoint(x: bounds.origin.x + (bounds.size.width - labelSize.width) / 2, y: bounds.origin.y + yPadding))
    }
}

// Provides the attachment button view to the text layout system.
private class ExpandableAttachmentViewProvider: NSTextAttachmentViewProvider {
    override func loadView() {
        let buttonView = AttachmentButtonView()
        buttonView.textAttachment = textAttachment as? ExpandableAttachment
        view = buttonView
    }
}

// A text attachment that toggles between showing full text and a truncated preview.
class ExpandableAttachment: NSTextAttachment {
    weak var textLayoutManager: NSTextLayoutManager?
    var hiddenContent: NSAttributedString?

    override func viewProvider(
        for parentView: PlatformView?, location: NSTextLocation, textContainer: NSTextContainer?
    ) -> NSTextAttachmentViewProvider? {
        let viewProvider = ExpandableAttachmentViewProvider(
            textAttachment: self, parentView: parentView,
            textLayoutManager: textContainer?.textLayoutManager,
            location: location)
        viewProvider.tracksTextAttachmentViewBounds = true
        return viewProvider
    }

    // Toggle between showing the full document text and only the first paragraph.
    func toggleHidden() {
        guard let textStorage = (textLayoutManager?.textContentManager as? NSTextContentStorage)?.textStorage else { return }
        textLayoutManager?.textContentManager?.performEditingTransaction {
            if hiddenContent != nil {
                // Reveal the hidden content by replacing the ellipsis character.
                let ellipsisRange = NSRange(location: textStorage.length - 2, length: 1)
                textStorage.replaceCharacters(in: ellipsisRange, with: hiddenContent!)
                hiddenContent = nil
            } else {
                // Hide everything after the first paragraph, replacing it with an ellipsis.
                let paragraphEnd = (textStorage.string as NSString).range(of: "\n").location
                guard paragraphEnd != NSNotFound else { return }
                let hidingRange = NSRange(
                    location: paragraphEnd + 1,
                    length: textStorage.length - paragraphEnd - 1 - 1)
                hiddenContent = textStorage.attributedSubstring(from: hidingRange)
                textStorage.replaceCharacters(in: hidingRange, with: "\u{2026}")
            }
        }
    }
}

// MARK: - Sample Text Loading

private extension NSTextStorage {
    // Load rich text and append a view-based attachment at the end.
    func loadAttachmentSampleText(textLayoutManager: NSTextLayoutManager) {
        guard let fileURL = Bundle.main.url(forResource: "AttachmentSample", withExtension: "rtf") else {
            fatalError("Failed to find AttachmentSample.rtf in the app bundle.")
        }
        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.rtf
        ]
        guard let sampleText = try? NSAttributedString(url: fileURL, options: options, documentAttributes: nil) else {
            fatalError("Failed to load sample text.")
        }
        replaceCharacters(in: NSRange(location: 0, length: length), with: sampleText)

        addAttribute(.foregroundColor, value: PlatformColor.platformTextColor, range: NSRange(location: 0, length: length))

        let attachment = ExpandableAttachment()
        attachment.allowsTextAttachmentView = true
        attachment.textLayoutManager = textLayoutManager
        let attachmentAttributedString = NSAttributedString(attachment: attachment)
        append(attachmentAttributedString)
    }
}
