/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
Logic for inline attachments text view.
*/

import AVKit

// MARK: - Container View

class InlineAttachmentsContainerView: PlatformContainerView {
    let textView = PlatformTextView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout(textView)
        #if !os(macOS)
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        #endif

        // Register the reuse policy so the text view caches the animation view provider
        // and its rendering surface across paragraph edits and viewport scrolling, instead of recreating them each time.
        textView.register(
            [.onScrollingOutOfViewport, .onEditingInlineParagraphs],
            forTextAttachmentViewProviderType: AnimatedAttachmentViewProvider.self
        )

        textView.textColor = PlatformColor.platformTextColor
        guard let textLayoutManager = textView.textLayoutManager,
              let textContentStorage = textLayoutManager.textContentManager as? NSTextContentStorage,
              let textStorage = textContentStorage.textStorage else { return }

        textStorage.loadInlineAttachmentSampleText(textLayoutManager: textLayoutManager)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

// MARK: - Animated Attachment View

private class AnimatedAttachmentView: PlatformView {
    #if os(macOS)
    private let playerView = AVPlayerView()
    #else
    private let playerLayer = AVPlayerLayer()
    #endif
    private var player: AVQueuePlayer?
    private var looper: AVPlayerLooper?

    override init(frame: CGRect) {
        super.init(frame: frame)

        guard let movieURL = Bundle.main.url(forResource: "AnimationSample", withExtension: "mov") else {
            return
        }
        let item = AVPlayerItem(url: movieURL)
        let player = AVQueuePlayer(items: [item])
        player.isMuted = true
        self.player = player
        self.looper = AVPlayerLooper(player: player, templateItem: item)

        #if os(macOS)
        wantsLayer = true
        layer?.cornerRadius = 4
        layer?.masksToBounds = true
        playerView.player = player
        playerView.controlsStyle = .none
        playerView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(playerView)
        NSLayoutConstraint.activate([
            playerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            playerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            playerView.topAnchor.constraint(equalTo: topAnchor),
            playerView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        #else
        backgroundColor = .clear
        playerLayer.player = player
        playerLayer.videoGravity = .resizeAspectFill
        layer.addSublayer(playerLayer)
        #endif

        player.play()
        player.rate = 0.3
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    #if !os(macOS)
    override func layoutSubviews() {
        super.layoutSubviews()
        playerLayer.frame = bounds
    }
    #endif
}

// MARK: - View Provider

class AnimatedAttachmentViewProvider: NSTextAttachmentViewProvider {
    override func loadView() {
        view = AnimatedAttachmentView()
    }

    override func attachmentBounds(
        for attributes: [NSAttributedString.Key: Any],
        location: any NSTextLocation,
        textContainer: NSTextContainer?,
        proposedLineFragment: CGRect,
        position: CGPoint
    ) -> CGRect {
        let font = attributes[.font] as? PlatformFont
        let height = (font?.pointSize ?? proposedLineFragment.height)
        let aspectRatio: CGFloat = 1454.0 / 838.0
        return CGRect(origin: .zero, size: CGSize(width: height * aspectRatio, height: height))
    }
}

// MARK: - Attachment

private class AnimatedAttachment: NSTextAttachment {
    override func viewProvider(
        for parentView: PlatformView?, location: any NSTextLocation, textContainer: NSTextContainer?
    ) -> NSTextAttachmentViewProvider? {
        let provider = AnimatedAttachmentViewProvider(
            textAttachment: self, parentView: parentView,
            textLayoutManager: textContainer?.textLayoutManager,
            location: location)
        provider.tracksTextAttachmentViewBounds = true
        return provider
    }
}

// MARK: - Sample Text Loading

private extension NSTextStorage {
    func loadInlineAttachmentSampleText(textLayoutManager: NSTextLayoutManager) {
        guard let fileURL = Bundle.main.url(forResource: "InlineAttachmentSample", withExtension: "rtf") else {
            fatalError("Failed to find InlineAttachmentSample.rtf in the app bundle.")
        }
        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.rtf
        ]
        guard let sampleText = try? NSAttributedString(url: fileURL, options: options, documentAttributes: nil) else {
            fatalError("Failed to load sample text.")
        }
        replaceCharacters(in: NSRange(location: 0, length: length), with: sampleText)

        addAttribute(.foregroundColor, value: PlatformColor.platformTextColor, range: NSRange(location: 0, length: length))

        let attachmentChar = String(Character(UnicodeScalar(NSTextAttachment.character)!))

        // Insert an animated attachment at the beginning of every line, iterating in reverse
        // so earlier insertion indices remain valid.
        let text = string as NSString
        var lineStart = text.length
        while lineStart > 0 {
            var start = 0
            text.getLineStart(&start, end: nil, contentsEnd: nil, for: NSRange(location: lineStart - 1, length: 0))
            lineStart = start

            let attachment = AnimatedAttachment(data: nil, ofType: nil)
            attachment.allowsTextAttachmentView = true

            var attrs = attributes(at: lineStart, effectiveRange: nil)
            attrs[.attachment] = attachment
            let attachmentString = NSAttributedString(string: attachmentChar + " ", attributes: attrs)
            insert(attachmentString, at: lineStart)

            if lineStart == 0 { break }
        }
    }
}
