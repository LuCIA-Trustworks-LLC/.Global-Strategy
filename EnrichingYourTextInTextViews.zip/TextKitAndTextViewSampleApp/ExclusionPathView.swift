/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
Logic for text view with an exclusion path.
*/

// MARK: - Container View

class ExclusionPathContainerView: PlatformContainerView {
    let textView = PlatformTextView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout(textView)
        #if !os(macOS)
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        #endif
        loadExclusionPathSampleText()
        configureExclusionPath()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func configureExclusionPath() {
        let bezierPath = ExclusionPath.bezierPath
#if os(macOS)
        let origin = CGPoint(x: 75, y: 50)
        let scale = 1.0
        var transform = AffineTransform.identity
        transform.translate(x: origin.x, y: origin.y)
        transform.scale(scale)
        bezierPath.transform(using: transform)
        textView.textContainer?.exclusionPaths = [bezierPath]
        textView.textColor = .platformTextColor
        
        guard let hammerImage = NSImage(named: NSImage.Name("Hammer")) else { return }
        hammerImage.size = CGSize(width: hammerImage.size.width * scale, height: hammerImage.size.height * scale)
        let imageView = PlatformImageView(image: hammerImage)
        imageView.frame = CGRect(origin: origin, size: hammerImage.size)
#else
        let origin = CGPoint(x: 50, y: 150)
        let scale = 0.6
        let transform = CGAffineTransform.identity.translatedBy(x: origin.x, y: origin.y).scaledBy(x: scale, y: scale)
        bezierPath.apply(transform)
        textView.textContainer.exclusionPaths = [bezierPath]
        
        let hammerImage = #imageLiteral(resourceName: "Hammer")
        let imageSize = CGSize(width: hammerImage.size.width * scale, height: hammerImage.size.height * scale)
        // Exclusion paths use the text container coordinate system, so convert to the text view coordinate system.
        let imageOrigin = CGPoint(x: origin.x + textView.textContainerInset.left,
                                  y: origin.y + textView.textContainerInset.top)
        let imageView = PlatformImageView(image: hammerImage)
        imageView.frame = CGRect(origin: imageOrigin, size: imageSize)
#endif
        textView.addSubview(imageView)
    }
    
    // MARK: - Sample Text Loading

    // Load rich text formatted (RTF) sample content for the exclusion path demonstration.
    func loadExclusionPathSampleText() {
        guard let fileURL = Bundle.main.url(forResource: "ExclusionPathSample", withExtension: "rtf") else {
            fatalError("Failed to find ExclusionPathSample.rtf in the app bundle.")
        }
        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.rtf
        ]
        guard let sampleText = try? NSAttributedString(url: fileURL, options: options, documentAttributes: nil) else {
            fatalError("Failed to load sample text.")
        }

        guard let textContentStorage = textView.textLayoutManager?.textContentManager as? NSTextContentStorage,
              let textStorage = textContentStorage.textStorage else { return }

        textContentStorage.performEditingTransaction {
            let range = NSRange(location: 0, length: textStorage.length)
            
            textStorage.replaceCharacters(in: range, with: sampleText)
            textStorage.addAttribute(.foregroundColor, value: PlatformColor.platformTextColor, range: range)
        }
    }
}

// MARK: - Exclusion Path Geometry

// Generate a bezier path that traces the outline of the hammer image.
struct ExclusionPath {
    private static var cgPath: CGPath {
        let path = CGMutablePath()
        path.move(to: CGPoint(x: 25.5, y: 58.5))
        path.addCurve(to: CGPoint(x: -0.5, y: 153.5), control1: CGPoint(x: -8.24, y: 100.69), control2: CGPoint(x: -0.5, y: 153.5))
        path.addLine(to: CGPoint(x: 112.5, y: 153.5))
        path.addLine(to: CGPoint(x: 140.5, y: 182.5))
        path.addLine(to: CGPoint(x: 237.5, y: 87.5))
        path.addLine(to: CGPoint(x: 260.5, y: 109.5))
        path.addLine(to: CGPoint(x: 299.5, y: 74.5))
        path.addCurve(to: CGPoint(x: 245.5, y: 18.5), control1: CGPoint(x: 299.5, y: 74.5), control2: CGPoint(x: 256.5, y: 29.5))
        path.addCurve(to: CGPoint(x: 165.5, y: 23.5), control1: CGPoint(x: 234.5, y: 7.5), control2: CGPoint(x: 188.5, y: -6.5))
        path.addCurve(to: CGPoint(x: 112.5, y: 13.5), control1: CGPoint(x: 154.5, y: 15), control2: CGPoint(x: 132.5, y: 13.5))
        path.addCurve(to: CGPoint(x: 25.5, y: 58.5), control1: CGPoint(x: 77.19, y: 13.86), control2: CGPoint(x: 44.21, y: 35.11))
        path.closeSubpath()
        return path.copy(using: [CGAffineTransform(translationX: 45, y: 65)])!
    }

    static var bezierPath: PlatformBezierPath { PlatformBezierPath(cgPath: cgPath) }
}

