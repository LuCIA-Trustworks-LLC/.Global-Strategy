/*
See the LICENSE.txt file for this sample's licensing information.

Abstract:
Logic for text view with line numbers in a side gutter.
*/

// MARK: - Container View

class LineNumberingContainerView: PlatformContainerView {
    fileprivate let gutterView = GutterView()
    fileprivate let textView = LineNumberedTextView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        textView.containerView = self
        setupLayout(textView)
        loadSampleText()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented.") }

    private func loadSampleText() {
        guard let fileURL = Bundle.main.url(forResource: "LineNumberingSample", withExtension: "json"),
              let contents = try? String(contentsOf: fileURL, encoding: .utf8) else { return }
        #if os(macOS)
        textView.string = contents
        textView.textColor = PlatformColor.platformTextColor
        #else
        textView.text = contents
        #endif
        textView.font = PlatformFont.monospacedSystemFont(ofSize: 24, weight: .regular)
        // Make the text view read-only to avoid incremental updates to the paragraph cache
        // because that isn't the focus of this sample app. Real-world apps can support
        // editing by updating the cache when the text changes.
        textView.isEditable = false
    }

    override func setupConstraints(_ contentView: PlatformView ) {
        NSLayoutConstraint.activate([
            gutterView.leadingAnchor.constraint(equalTo: leadingAnchor),
            gutterView.topAnchor.constraint(equalTo: topAnchor),
            gutterView.bottomAnchor.constraint(equalTo: bottomAnchor),
            gutterView.widthAnchor.constraint(equalToConstant: 44),
            contentView.leadingAnchor.constraint(equalTo: gutterView.trailingAnchor),
            contentView.trailingAnchor.constraint(equalTo: trailingAnchor),
            contentView.topAnchor.constraint(equalTo: topAnchor),
            contentView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    override func setupLayout(_ textView: PlatformTextView) {
        gutterView.translatesAutoresizingMaskIntoConstraints = false

        addSubview(gutterView)
        super.setupLayout(textView)
    }

    // Called by the text view from `textViewportLayoutControllerDidLayout(_:)`.
    // Determines line numbers for visible paragraphs and updates the gutter.
    fileprivate func viewportDidLayout(_ textViewportLayoutController: NSTextViewportLayoutController) {
        guard let layoutManager = textView.textLayoutManager,
              let viewportRange = textViewportLayoutController.viewportRange,
              let storage = layoutManager.textContentManager as? NSTextContentStorage else { return }

        // Determine the line index of the first paragraph in the viewport.
        // Try the cache first, and fall back to full enumeration if the paragraph isn't in the cache.
        var firstViewportIndex: Int? = nil

        storage.enumerateTextElements(from: viewportRange.location, options: []) { element in
            if let paragraph = element as? NSTextParagraph,
               let cached = self.textView.cachedIndex(for: paragraph) {
                firstViewportIndex = cached
            }
            return false
        }

        if firstViewportIndex == nil {
            var count = 0
            storage.enumerateTextElements(from: storage.documentRange.location, options: []) { element in
                guard let paragraph = element as? NSTextParagraph,
                      let elementRange = paragraph.elementRange else { return true }

                if elementRange.location.compare(viewportRange.location) != .orderedAscending {
                    firstViewportIndex = count
                    return false
                }
                self.textView.paragraphIndexCache.setObject(NSNumber(value: count), forKey: paragraph)
                count += 1
                return true
            }
            if firstViewportIndex == nil {
                firstViewportIndex = count
            }
        }

        // Go through the paragraphs in the viewport and build gutter line info.
        let viewportOriginY = textView.viewportBounds(for: textViewportLayoutController).minY
        var lineInfo: [(index: Int, frame: CGRect)] = []
        var currentIndex = firstViewportIndex!

        layoutManager.enumerateTextLayoutFragments(from: viewportRange.location, options: []) { fragment in
            if let elementRange = fragment.textElement?.elementRange,
               elementRange.location.compare(viewportRange.endLocation) == .orderedDescending {
                return false
            }

            if let paragraph = fragment.textElement as? NSTextParagraph {
                self.textView.paragraphIndexCache.setObject(currentIndex as NSNumber, forKey: paragraph)
                let yOrigin = fragment.layoutFragmentFrame.minY - viewportOriginY
                let frame = CGRect(x: 0, y: yOrigin, width: self.gutterView.bounds.width, height: fragment.layoutFragmentFrame.height)
                lineInfo.append((currentIndex, frame))
                currentIndex += 1
            }
            return true
        }

        textView.cacheInvalidAfterLocation = nil
        gutterView.rebuild(with: lineInfo)
    }
}

// MARK: - Line Numbered Text View

private class LineNumberedTextView: PlatformTextView {
    weak var containerView: LineNumberingContainerView?

    // Maps each paragraph to its index.
    // Using weak keys ensures that `NSMapTable` automatically removes entries for paragraphs that are no longer in use.
    var paragraphIndexCache: NSMapTable<NSTextParagraph, NSNumber> = .weakToStrongObjects()

    // The location at or after which cached indices are stale. A `nil` value means all caches are valid.
    var cacheInvalidAfterLocation: (any NSTextLocation)?

    func cachedIndex(for paragraph: NSTextParagraph) -> Int? {
        guard let num = paragraphIndexCache.object(forKey: paragraph) else { return nil }
        if let invalidLoc = cacheInvalidAfterLocation {
            guard let paragraphStart = paragraph.elementRange?.location else { return nil }
            if paragraphStart.compare(invalidLoc) != .orderedAscending {
                return nil
            }
        }
        return num.intValue
    }

    override func textViewportLayoutControllerDidLayout(_ textViewportLayoutController: NSTextViewportLayoutController) {
        super.textViewportLayoutControllerDidLayout(textViewportLayoutController)
        containerView?.viewportDidLayout(textViewportLayoutController)
    }
}

// MARK: - Gutter View

// Draws line number labels at the positions reported by the text view after layout.
private class GutterView: PlatformView {
    private var lineInfo: [(index: Int, frame: CGRect)] = []

    #if os(macOS)
    // Flipped coordinate system so Y increases downward, matching the text view.
    override var isFlipped: Bool { true }
    #endif

    override init(frame: CGRect) {
        super.init(frame: frame)

        #if os(macOS)
        wantsLayer = true
        layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
        #else
        backgroundColor = .systemBackground
        #endif
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func rebuild(with lineInfo: [(index: Int, frame: CGRect)]) {
        self.lineInfo = lineInfo
        #if os(macOS)
        needsDisplay = true
        #else
        setNeedsDisplay()
        #endif
    }

    override func draw(_ rect: CGRect) {
        let attributes: [NSAttributedString.Key: Any] = [
            .font: PlatformFont.monospacedSystemFont(ofSize: 20, weight: .regular),
            .foregroundColor: PlatformColor.platformSecondaryLabel
        ]
        for (index, frame) in lineInfo {
            guard frame.intersects(rect) else { continue }
            let label = "\(index + 1)" as NSString
            let labelSize = label.size(withAttributes: attributes)
            let xOrigin = bounds.width - labelSize.width - 6
            let yOrigin = frame.minY
            label.draw(at: CGPoint(x: xOrigin, y: yOrigin), withAttributes: attributes)
        }
    }
}
