# Enriching your text in text views

Support line numbering, section collapsing, inline attachment caching, exclusion paths, text attachments, and text lists in a text view.

## Overview

- Note: This sample code project is associated with the following WWDC sessions:
  - WWDC26 session [370: Elevate your app’s text experience with TextKit](https://developer.apple.com/wwdc26/370/).
  - WWDC22 session [10090: What's new in TextKit and text views](https://developer.apple.com/wwdc22/10090/).
